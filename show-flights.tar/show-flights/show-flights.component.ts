import { Component, OnInit } from '@angular/core';
import { Flight } from './Flight';

@Component({
  selector: 'app-show-flights',
  templateUrl: './show-flights.component.html',
  styleUrls: ['./show-flights.component.css']
})
export class ShowFlightsComponent implements OnInit {

  title: string = 'Showing All Flights';
  
  flightNumber: number = 100;  flightName: string =" Air India";
  flightSource: string ="Mumbai"; flightTarget: string ="Paris";

   flightObj: Flight = new Flight();

   flightList: Flight[] = [
      {flightNumber:100,flightName:"Lufthansa",flightSource:"Mumbai",flightTarget:"Germany",
        crewList: [
          {firstName:'Jack',age:32,designation:"Co-Pilot"},
          {firstName:'Jane',age:30,designation:"Captain"},
          {firstName:'Julie',age:32,designation:"AirHostess"}
        ]
    },
      {flightNumber:200,flightName:"British Airways",flightSource:"Mumbai",flightTarget:"London",
      crewList: [
        {firstName:'Sachin',age:32,designation:"Co-Pilot"},
        {firstName:'Anjali',age:30,designation:"Captain"},
        {firstName:'Julia',age:32,designation:"AirHostess"}
      ]
    },

      {flightNumber:300,flightName:"American Airlines",flightSource:"Mumbai",flightTarget:"Ney York",
      crewList: [
        {firstName:'Smith',age:42,designation:"Co-Pilot"},
        {firstName:'Miller',age:20,designation:"Captain"},
        {firstName:'Rita',age:22,designation:"AirHostess"}
      ]
    },
      {flightNumber:400,flightName:"Air France ",flightSource:"Mumbai",flightTarget:"Paris",
      crewList: [
        {firstName:'Smith',age:42,designation:"Co-Pilot"},
        {firstName:'Miller',age:20,designation:"Captain"},
        {firstName:'Rita',age:22,designation:"AirHostess"}
      ]
    },
      {flightNumber:500,flightName:"Lufthansa",flightSource:"Mumbai",flightTarget:"Germany",
      crewList: [
        {firstName:'Smith',age:42,designation:"Co-Pilot"},
        {firstName:'King',age:20,designation:"Captain"},
        {firstName:'Rima',age:22,designation:"AirHostess"}
      ]
    },
      {flightNumber:600,flightName:"Air India",flightSource:"Mumbai",flightTarget:"Washington",
      crewList: [
        {firstName:'Roy',age:44,designation:"Co-Pilot"},
        {firstName:'Sam',age:27,designation:"Captain"},
        {firstName:'Jenifer',age:28,designation:"AirHostess"}
      ]
    },

      {flightNumber:700,flightName:"Nepal Airlines",flightSource:"Mumbai",flightTarget:"Kathmandu",
      crewList: [
        {firstName:'Chang',age:38,designation:"Co-Pilot"},
        {firstName:'Jackie',age:33,designation:"Captain"},
        {firstName:'Roma',age:22,designation:"AirHostess"}
      ]},

      {flightNumber:800,flightName:"Emirates",flightSource:"Mumbai",flightTarget:"Dubai",
      crewList: [
        {firstName:'Amit',age:432,designation:"Co-Pilot"},
        {firstName:'Adam',age:22,designation:"Captain"},
        {firstName:'Zeenat',age:21,designation:"AirHostess"}
      ]}
    ]; 
   



  constructor() { }

  ngOnInit(): void {
  }

}
