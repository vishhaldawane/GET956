/*
 * 		MVC
 * 
 *    Controller
 * 
 * Model		View		
 * 
 * 
 */
package com.lti;

import com.lti.controller.FlightController;
import com.lti.model.Flight;
import com.lti.view.FlightView;
//One Person : plays three roles : 1. Order collector, 1. Chef, 1. Presenter

//three People : 1. Controller     2. Chef       3. Presenter [VIEW]

//people selling Idli Sambar : Cycle, SevPuri at seaShore

//Person with White Clothes : Red Tilak : Gold Chain [ 50 gms ]
// White Innova crysta
//white sandals

//portals : PNR  ->railway  PNR -> airlines  EMPNO->COMPANY    ROLLNO-> COLLEGE

					/*comment1*/
/*comment2*/	public class MVCPattern { /*comment3*/
					/*comment4*/
	
	/*comment4*/
	public static void main(String[] args) {
		//POJO - plain old java object - Flight - MODEL (data)
		Flight model = new Flight();
		//SavingsAccount
		//Employee
		//...
		model.setFlightNumber(101);
		model.setFlightName("Air India");
		
		
		// FlightView - VIEW 
		// SavingsAccountView
		// EmployeeView
		// ....
		FlightView view = new FlightView();
		
		// FlightController - CONTROLLER
		FlightController controller = new FlightController(model, view);
		//SavingsAccountController
		//EmployeeController
		
		controller.updateFlightView();
		controller.setFlightName("Lufthansa");
		controller.updateFlightView();
		controller.updateFlightObjectView();

		
		
	}
}
