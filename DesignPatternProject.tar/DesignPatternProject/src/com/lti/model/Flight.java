package com.lti.model; //MODEL (DATA)
//Flight f1 = new Flight(101,"AirIndia");
//Flight f2 = new Flight(101,"AirIndia");
//....
public class Flight {
	
	private int flightNumber;
	private String flightName;
	
	public int getFlightNumber() {
		return flightNumber;
	}
	public void setFlightNumber(int flightNumber) {
		this.flightNumber = flightNumber;
	}
	public String getFlightName() {
		return flightName;
	}
	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}
	
	
}
