//deep breathing - mind is alert

//if you observe your breathing...you are back to yourself - you are the owner

// if their questions - will take away your attention from your breathing...

// pay bi-directioanl focus on outside of yourself and your breathing too

// double arrow
// double edged sword

// two swords - no shield
// BajiPrabhu Deshpande  - Tanaji Malusure



public class SttaicTest {
	public static void main(String[] args) {
		
		//how many kites are here at line 5 
		
		Kite.setKiteCount(100);
		
		System.out.println("Total kites : "+Kite.getKiteCount());
		
		Kite k1 = new Kite("Akshita","Pink",50);
		Kite k2 = new Kite("Swhetha","Yellow",60);
		Kite k3 = new Kite("Krieethika","Red",70);
		
		//how many kites are here at line 5 
		System.out.println("Total kites : "+Kite.getKiteCount());
		
		System.out.println("k1 "+k1);
		System.out.println("k2 "+k2);
		System.out.println("k3 "+k3);
		
		
	}
}
//mar java, mit java, loot java, gir java, so java, kar java
// jit java

class Kite
{
	String kiteOwner;
	String kiteColor;
	int kiteLength;
	
	public static int getKiteCount() { // is it an object method or class method?
		
		return kiteCount;
	}
	public static void setKiteCount(int kiteCount) {
		Kite.kiteCount = kiteCount;
	}
	//you can refer it with the ClassNAme
	//2. rather it is the member of the class [ shared across all object of that class ]
	private static int kiteCount; // 1. it is not the member of the object
	
	public Kite(String kiteOwner, String kiteColor, int kiteLength) {
		super();//inorder to validate teh data structure of the parent class
					// it is necessary to have super() as a first line.
				//eg. in order to create and Employee, who is child of
				//Student, who is child of Person
				// it is essential to validate the [Person]'s details
				// post to it [Student]'s detail and at last
				// the details of the Employee
		//										Person       Student    Employee
				//Employee  e= new Employee('M',22,"Jack",  120,89.67,  101,"LTI");
		System.out.println("Kite created....");
		//super() must be called from a constructor
		//and not any other method
		
		//super.  - is used to call object methods/data members
						//from consturctor or any other method
						//anywhere as a linenumber
		
		kiteCount++; // a static can be called from non-"static"
		this.kiteOwner = kiteOwner;
		this.kiteColor = kiteColor;
		this.kiteLength = kiteLength;
		
		//is it im"possible"
	}
	@Override
	public String toString() {
		return "Kite [kiteOwner=" + this.kiteOwner + ", kiteColor=" + kiteColor + ", kiteLength=" + kiteLength + "]";
	}
	
}
