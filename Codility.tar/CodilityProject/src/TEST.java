/*
 * 7 HABITS OF HIGHLY EFFECTIVE PEOPLE
 * - STEPHEN COVEY
 * 
 * PRIVATE VICTORY - PERSONALIZED VICTORY
 * 1. BE PROACTIVE
 * 2. PUT FIRST THING FIRST
 * 3. BEGIN WITH THE END IN MIND
 * 
 * 4. THINK WIN-WIN  ( YOU ALSO WIN - HE/SHE/THEY ALSO WIN )
 * 
 * PUBLIC VICTORY
 * 5. SEEK FIRST TO UNDERSTAND THEN TO BE UNDERSTOOD
 * 6. SYNERGY - 
 * 7. SHARPEN THE SAW - "APPLIED" KNOWLEDGE CONVERTED INTO WISDOM
 * 
 * 	OOPS
 * 
 * SME - COMES -
 * 		WHAT IS AN ABSTRACT CLASS
 * 			- it is a class with OPTIONAL    partial      contract 
 * 								may/maynot     <-- abstract functions->
 * 			- it is meant for inheritance
 * 
 *
 *abstract is a synonym of the english word : incomplete
 *
 *  abstract/incomplete class BankAccount  { //legal
 *  		//may not have abstract methods
 *  }
 *  
 *  class BankAccount { //illegal
 *    abstract void withdraw(); //mustreside in an abstract class
 *  }
 *  
 *  abstract class BankAccount {
 *  		abstract void withdraw();
 *  		void show() { }
 *  		BankAccount() { } <-- used by the children
 *  }
 *  //instance of abstract class can never be created
 *  //but a reference to an abstract class can be created
 *   class SavingsAccount extends BankAccount {
 *   		void withdraw() { } // mandate recieved and fulfilled by non-abstract immediate child
 *   }
 *  what if the SavingsAccount is also abstract then?
 *  - the it is not a mandate to fulfil the withdraw() body
 *  
 *  it can be forwarded to the next child of SavingsAccount
 *  
 *   
 * 	 - UNDERSTAND THEIR WORDS - HEAR IT CLEARLY -
 * 
 * DONT HEAR THEM AS PER YOUR COMFORT
 * 
 *	WHAT WORDS ARE THEY USING
 *
 *   CONFIDENCE CHECK 
 *   
 * 
 * 
 * 
 */
public class TEST {

}
