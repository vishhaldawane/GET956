package com.lti.datetime;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class DateTimeDemo {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Scanner sc1 = new Scanner(System.in);
		
		LocalDate date=LocalDate.of(2000, 12, 13); 
		System.out.println(date);

		System.out.println(LocalDate.now());


		System.out.println("Enter your date of birth(yyyy-mm-dd):");
		String dob=sc.next(); 
		LocalDate dob1=LocalDate.parse(dob);
		System.out.println(dob1);


		System.out.println("Enter date of joining(MMM dd,yyyy):");
		String acceptedDate = sc1.nextLine(); // "JAN 21,1999";

		DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("MMM dd,yyyy");

		LocalDate formattedDate = LocalDate.parse(acceptedDate, dateFormat);
		System.out.println(formattedDate);

		// Internationalization

		for (String zoneId : ZoneId.getAvailableZoneIds()) {

			ZoneId id = ZoneId.of(zoneId);
			System.out.println(id);
		}
		// Zone
		LocalDate newyorkDate = LocalDate.now(ZoneId.of("Pacific/Honolulu"));
		System.out.println(newyorkDate);

		LocalTime time=LocalTime.of(10, 20, 56);
		System.out.println(time);

		LocalTime honoluluTime=LocalTime.now(ZoneId.of("Pacific/Honolulu"));
		System.out.println(honoluluTime);

		LocalTime sydneyTime = LocalTime.now(ZoneId.of("Australia/Sydney"));
		System.out.println(sydneyTime);

	}

}
