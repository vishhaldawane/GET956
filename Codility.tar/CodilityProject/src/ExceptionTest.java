
//SME : vocal   - talking
//YOU : vocal   - listening - active listening 

//YOU : vocal   - talking + typing 
//					EAR   + SEE

// HUMAN BRAIN = BIO HACK =    SEQUENCE OF LEARNING

// SAREE PRICE ON A TAG[SEE] + 
// SAREE ON A STATUE/PRICE TAG [SEE] + 
// SAREE WITHOUT PRICE TAG AND NO STATUE

//CAN YOU HAVE HAIRCUT ON THE PHONE

//dml --> ddl


public class ExceptionTest {
	public static void main(String[] args) {
		
	}
}
