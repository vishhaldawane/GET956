import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
}) //1.ng generate service CurrencyConveter
export class CurrencyConverterService {
  constructor() { }
  convert() { //2.
    
    console.log("convert is called.....");
    this.findCurrencyRate();
  }
  findCurrencyRate() {
    console.log('finding currency rate');
  }
}
