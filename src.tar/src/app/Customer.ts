export class Customer { 
	 customerId : number;
	 customerName : string;
	 city : string;
}

/*
make a new project
  1. ng new airline
  2. cd airline
also open this folder in vs code
  1. file -> open -> select folder airline

  airline
   |
   src -app->
		|
		AppComponent   | A Java Bean 
		|
---------------------------------------------------
|					    |					      |
TS app.component.ts  <> app.component.html	# app.component.css
class AppComponent     <h1> Welcome <h1>    h1 { color:red; }
{
	title="Employee Project"
}


*/