/*

      a.js    b.js    c.js
      a.html  b.html    c.html        a.css   b.css   c.css


      Component DRiven Way

                Angular coding by them...
                theyare ready with their framework [ semi developed application ]

      A                               B
      |                               |
      ----------------      ------------------
       |       |      |         |      |      |
      a.html a.css  a.ts      b.html  b.css   b.ts

                  Iterable
                    |  Iterator iterator();
                    Collection
                      |add(Object), remove();
                -----------
                |         |
              List          Set
              |              |
              LL AL           TS  HS
              add add         add  add
*/




import { Component } from '@angular/core';

@Component({
  selector: 'app',             // <script> let p = document.getElementById("principal").value;  </script>
  templateUrl: './app.component.html', //old: VIEW <input type=text id="principal" value=10000>
  styleUrls: ['./app.component.css']    //1 <input type=text value={{principal}}>
})                                  //2 <input type=text  [value]="principal">
                                   //3. <input type=text [(ngModel)]="principal" >
export class AppComponent { // MODEL
  title = 'Emi Calculator';                 //ArrayList jukeBox.add(s1);
  principal: number = 10000;
  rate: number = 10.0;
  years: number = 1;
  si: number = (this.principal * this.rate * this.years)/100;
  isUserLoggedIn: boolean= true;
  
  accountOpeningDate = new Date();

  calculateSimpleInterest() {
    
    this.si = (this.principal * this.rate * this.years)/100;
    console.log('calculated simple interest ',this.si);
  }

}
/*
              angular f/w
              [], @Decorator, @NgModule, @Pipe,
              *ngIf, *ngFor, [()] {{}}

              
  Akshita                 Shwetha
  |                         |
  Airline                   Banking
  |                           |
  FlightEnquiryComponent    AddPayeeComponent
  ts + html + css           ts + html + css



                  Banking Project
        Akshita : Amrita Ameya      Anirudh       Akhilesh 
          |         |       |           |             |
       User     payee   fundtransfer  statement   registration/login   
layer1  ?       table
layer2  ?       pojo
layer3  ?       repo/jdbc+with Junit Testing
layer4          service | with Junit Testing
layer5          controller
layer6          angular
                  |
                  AddPayeeComponent
                  ViewPayeeComponent
                  ViewAllPayeeComponent
                  DeletePayeeComponent

                  laptop speed issue/hang/harddisk crash issue/network/powerfailure
                  h/w s/w p/w 
                  
                            Akshita : Amrita Ameya      Anirudh       Akhilesh   (350 man hours)
Project Day1 28-09-2021 TUE   10      10      10        10            10        = 50 hours
Project Day2 29-09-2021 WED
Project Day3 30-09-2021 THU
Project Day4 01-09-2021 FRI

Project Day5 02-09-2021 SAT
Project Day6 03-09-2021 SUN

Project Day7 04-09-2021 MON
Project Day1 04-09-2021 TUE <-- no coding on this day


 
          Model View Controller Architecture / Design Pattern

  if there is a small hotel
  A is the owner of the hotel
  A is the Chef
  A is the order taker
  A is the food server

         Kitchen [ model means data | database | arraylist | ts ]
                  |                                         p/n/y
                  | C - Chef - Dosa/Pizza/FriedRice
                  |            B      B     B <-- View [ html + css ]
      ---------------------
      | A      |A     A <-- Controllers
      Dining1 Dining2 ....  ..... ...
      |       |
    Customer1 Customer2 ... CustomerN  .. 50
 

    Directives



    Structural
        *ngFor
        *ngIf


          +-------+
          | LOGIN | <-- if i click on this button, then the label should be changed as
          +-------+     LOGOUT <-- if i click again, then the label should be reversed
                            as LOGIN


        Angular is a JavaScript Based Framework

        Installation : 1) node js LTS -> 2) npm command -> install angular CLI [ java ]
        3) IDE - Visual Studio Code [ eclipse ] -> New Project 

        C:\> Or $ -> ng new Airline <-- took much time to load the libraries 
        enter into Airline project
        $ cd airline >  
        $ airline > A DEFAULT COMPONENT IS GIVEN TO US-> AppComponent
    json - java script object notation 


              airline
              |
            -------
            |
            src
            |
            -----------------
            |             |
            AppModule   index.html
            |             <app> </app>
      ----------
      | selector : 'app'
      app <-- name of the component 
      |
  ------------------------------------------
  |  DATA + FUNCTIONS |    VIEW              |STYLE
  app.component.ts  app.component.html  app.component.css
   |                  |                   |
AppComponent        <> <><> <> <>     {} {}{} {} 
  |@Decorator
     




PHOTOFRAME MAKER SHOP
     |
     SEMI DEVELOPED ARCHITECTURE WITH THEM
     |
     THE PIC IS OWNED BY US
  

     Fresher
        SQL PLSQL
              |
              JPL    - IPL
              | Annotation  @DevelopedBy.....meta-data
              Mock Client
              | grade...
              |
              HTML CSS JS
              |
              ANGULAR - framework  @Component, @NgModule, @Pipe

         
              
              Services 
              |
        to serve a common code/funcionality
        across all components

        CurrencyConveterService       ValidationService
            |                             |
    -----------------             ------------------
    |                             |
    convert(s,t,a):ca {         validateDate(d1,d2) {}
      //calculation
  }                             }
        Angular as a controller will create the object
        ccs: CurrencyConveterService = new CurrencyConveterService()

            Dependency Injection 


RegisterComponent
      |  constructor() { }
  ------------------
  |       |         |
  html    css       ts
  |                 |
  button ->       callConvert() { will invoke the convert();  }
  button ->       registerThisNewUser(){}

ccs=ccs;
     a:CurrencyConveterService          b=ccs
           |                   b:CurrencyConveterService 
      html+css+ts            html+css+ts
    ShowFlightComponents | ForgotPasswordComponent |

    c=ccs           
   c:CurrencyConveterService      d=ccs 
   |                           d:CurrencyConveterService 
     html+css+ts            html+css+ts
    LoginComponent |        ResetPassword
    .....


    1. ng generate service CurrencyConveter
          this will create
          currency.converter.service.ts <- file
                |
            class CurrencyConveterService {
                convert() { }
            }
    2. in your desired component, based on any event decide to
    invoke the above convert() method via yours component's methods

              RegisterComponent
                |
                contructor(private ccs: CurrencyConverterService){}
                |
              callConvert() { <-- invoke this method based on click
                this.ccs.convert()
              }

class A {
  fun() {}
}
class B {
  foo() {}
}
class C {
  void far() {}
}
class D {
  void fee() {}
}
class E {
  void faa() {}
}
class F {
  void fin() { }
}
--
class A { // tables are here - layer 1
  fun() {}
}
class B {// pojo - layer 2
  foo() { A a = new A(); a.fun(); }
}
class C { // repo - layer 3
  void far() {B b = new B(); b.foo(); }
}
class D { // service - layer 4
  void fee() { C c = new C(); c.far(); }
}
class E { // spring controller - layer 5
  void faa() { D d = new D(); d.fee(); }
}
class Service { // seva - serve the community/ help others
  void serv() { E e = new E(); e.faa(); }
}
class F { //angular layer 6 
  void fin() { Service s = new Service();  s.serv(); }
}
  
//F'fin is invoking A's fun() method



html Routing
--------
        searchFlight.html
          |
    showFlight.html
        |
      ----------
            |
            Login.html -----  UserDashBoard.html
            |   |
    --------+   ----------------------------
    |               |                   |
  register.html   ForgotPassword.html  resetPassword.html


Angular component  Routing
--------
       AppComponent <--- we search the flights here 
          |
    ShowFlightComponent
        |
      ----------
            |
          LoginComponent -----  UserDashBoardComponent
            |   |
    --------+   -----------------------------------
    |                  |                        |
  RegisterComponent   ForgotPasswordComponent  ResetPasswordComponent

ng new Airline
Do you wish to generate routing ? Y/N


app-routing.module.ts


   */