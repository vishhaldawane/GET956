export class Flight {
    flightNumber: number = 200;  
    flightName: string ="Indian Airlines";
    flightSource: string ="London"; 
    flightTarget: string ="Germany";
    crewList: Crew[]; //hasA
}
export class Crew {
    firstName: string;
    age: number;
    designation: string;
}
export class Passenger {
    passengerName: string;
    ticket: FlightTicket; //hasA
}
export class FlightTicket {
    flightInfo: Flight; //hasA
    //departureDate
    //cost
    //number Of Passengers 
}