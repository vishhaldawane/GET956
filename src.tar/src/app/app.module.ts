import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';

import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { EmployeeManagementComponent } from './employee-management/employee-management.component';
import { ShowFlightsComponent } from './show-flights/show-flights.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { FormsModule } from '@angular/forms';
import { SqrtPipe } from './sqrt.pipe';
import { ButtonComponent } from './button/button.component';
import { HomeComponent } from './home/home.component';
import { UserDashboardComponent } from './user-dashboard/user-dashboard.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { AComponent } from './a/a.component';
import { BComponent } from './b/b.component';
import { CComponent } from './c/c.component';
//localhost:4200
@NgModule({
  declarations: [
    AppComponent,
    EmployeeManagementComponent,
    ShowFlightsComponent,
    LoginComponent,
    RegisterComponent,
    ResetPasswordComponent,
    ForgotPasswordComponent,
    SqrtPipe,
    ButtonComponent,
    HomeComponent,
    UserDashboardComponent,
    PageNotFoundComponent,
    AComponent,
    BComponent,
    CComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule, // add this
    HttpClientModule //add this
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
