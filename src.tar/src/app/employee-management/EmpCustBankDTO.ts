

export class EmpCustBankDTO {
	 employeenumber: number;
	 customerid: number
	 bankid: number;
	
}
