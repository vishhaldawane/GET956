import { createCssSelector } from '@angular/compiler/src/render3/view/template';
import { Component, OnInit } from '@angular/core';
import { ValidationErrors } from '@angular/forms';
import { CurrencyConverterService } from '../currency-converter.service';
import { ValidationService } from '../validation.service';
import { Registration } from './Registration';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
// 4. private on ccs means it is the data member and not a local var
registration: Registration; //just a ref
constructor(private ccs: 
  CurrencyConverterService, 
  private vs: ValidationService) { }
validateFormsUsername() { // this is your htmls associated method
  this.vs.validateUsername(
    this.newRegistration.
    username); //invoke the service's method
}
callCurrencyRate() { this.ccs.findCurrencyRate(); }
callConvert() { //<--- this is called on button click 
 console.log('callConvert() of register.component.ts is called.')
 /*5*/ this.ccs.convert(); //<-- actual service call
}



  newRegistration: Registration = new Registration();
  reEnteredPassword: string;

  registerThisNewUser(){
      console.log('registered user is ',this.newRegistration);
  }
  checkReEnteredPassword(){
    console.log('re-Entered password is ',this.reEnteredPassword);
    if(this.newRegistration.password != this.reEnteredPassword) {
      
    }
    
  }
 
  ngOnInit(): void {
  }

}

/*

         1 register.component.ts -> register.service.ts -> SPRING->JDBC->POJO->DB
                 |DATA                  registerIt() -->
          ----------------------------
        |                       |
     2 register.component.html 3 register.component.css
      VIEW                        STYLE





*/