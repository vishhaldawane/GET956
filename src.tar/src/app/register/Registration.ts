export class Registration {
    username: string;
    password: string;
    email: string;
    phone: string;
    birthdate: Date;
}