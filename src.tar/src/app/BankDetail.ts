export class BankDetail {
		 bankId : number;
		 bankAccountNumber: number;
		 bankName : string;
		 balance: number;
}