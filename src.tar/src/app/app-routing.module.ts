import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AComponent } from './a/a.component';
import { BComponent } from './b/b.component';
import { CComponent } from './c/c.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { RegisterComponent } from './register/register.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';
import { ShowFlightsComponent } from './show-flights/show-flights.component';
import { UserDashboardComponent } from './user-dashboard/user-dashboard.component';

/*
http://localhost:4200/
http://localhost:4200/home
http://localhost:4200/home/showFlights
http://localhost:4200/home/register
http://localhost:4200/home/login
http://localhost:4200/home/login/forgot
http://localhost:4200/home/login/forgot/reset
http://localhost:4200/home/login/dashboard

*/


const routes: Routes = [
  { path: 'home', component: HomeComponent},
  { path: '', redirectTo:'home', pathMatch:'full'},
  { path : 'register', component: RegisterComponent },
  { path : 'showFlights', component: ShowFlightsComponent },
  { path : 'login', component: LoginComponent},
  { path: 'dashboard', component: UserDashboardComponent},
  { path: 'forgot', component: ForgotPasswordComponent},      
  { path:'reset', component: ResetPasswordComponent},
  { path: '**', component: PageNotFoundComponent}
];

/*const routes: Routes = [
    {path : 'a', component: AComponent} ,
    {path:'b', component : BComponent},
    {path:'c', component : CComponent},
    {path : '', redirectTo: '/a', pathMatch: 'full'},
   {path : '**', component: PageNotFoundComponent}
];
*/

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
