package com.lti.java;

public class Bank {
	public static 
	SavingsAccount 
	getObject() {
		//return null;
		System.out.println("getObject()....");
	return new SavingsAccount(101,"Julie",5000);
	}
}
